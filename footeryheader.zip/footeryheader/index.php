<?php include "header.php" ?>
    <div class="container my-5">
        <div class="row">
            <div class="col text-center">
                <div class="card">
                    <div class="card-header display-6">
                        Acciones sobre BD <i class="bi bi-database"></i>
                    </div>
                    <div class="p-4">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Alta de producto</th>
                                <th scope="col">Baja de producto</th>
                                <th scope="col">Acutualizar producto</th>
                                <th scope="col">Listado de productos</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td scope="row"><a href="alta.php"><i class="bi bi-database-add" style="color:green ; font-size:2em"></i></a></td>
                                <td><a href="baja.php"><i class="bi bi-database-dash" style="color:red ; font-size:2em"></i></a></td>
                                <td><a href="actualizar.php"><i class="bi bi-database-fill-gear" style="color:blue ; font-size:2em"></i></a></td>
                                <td><a href="listado.php"><i class="bi bi-database" style="color:black ; font-size:2em"></i></a></td>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
        
<?php include "footer.php" ?>