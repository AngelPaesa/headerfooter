<?php
 $servidor = "localhost";
 $usuario = "root";
 $password = "";
 $basedatos = "productosbd";

 $conexion = mysqli_connect($servidor,$usuario,$password) or die('Error de conexion');

 mysqli_select_db($conexion, $basedatos);